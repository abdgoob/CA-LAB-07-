`timescale 1ns / 1ps

module RF_ALU_FSM_tb;

    reg clk;
    reg rst;

    reg WriteEnable;

    reg [4:0] rs1;
    reg [4:0] rs2;
    reg [4:0] rd;

    reg [31:0] WriteData;

    wire [31:0] ReadData1;
    wire [31:0] ReadData2;

    reg [2:0] ALUControl;

    wire [31:0] ALUResult;
    wire Zero;


    reg [3:0] state;
    reg [3:0] next_state;


    localparam IDLE = 4'h0;
    localparam WRITE_X1 = 4'h1;
    localparam WRITE_X2 = 4'h2;
    localparam WRITE_X3 = 4'h3;

    localparam DO_ADD = 4'h4;
    localparam DO_SUB = 4'h5;
    localparam DO_AND = 4'h6;
    localparam DO_OR  = 4'h7;
    localparam DO_XOR = 4'h8;
    localparam DO_SLL = 4'h9;
    localparam DO_SRL = 4'hA;
    localparam DO_BEQ = 4'hB;

    localparam DONE = 4'hC;


    RegisterFile rf (
        .clk(clk),
        .rst(rst),
        .WriteEnable(WriteEnable),
        .rs1(rs1),
        .rs2(rs2),
        .rd(rd),
        .WriteData(WriteData),
        .ReadData1(ReadData1),
        .ReadData2(ReadData2)
    );


    ALU alu (
        .A(ReadData1),
        .B(ReadData2),
        .ALUControl(ALUControl),
        .Result(ALUResult),
        .Zero(Zero)
    );


    always #5 clk = ~clk;


    // FSM state register
    always @(posedge clk or posedge rst) begin

        if (rst)
            state <= IDLE;

        else
            state <= next_state;

    end


    // FSM control logic
    always @(*) begin

        WriteEnable = 0;

        rs1 = 0;
        rs2 = 0;
        rd = 0;

        WriteData = 0;

        ALUControl = 3'b000;

        next_state = state;


        case (state)

            IDLE: begin
                next_state = WRITE_X1;
            end


            WRITE_X1: begin

                WriteEnable = 1;
                rd = 5'd1;

                WriteData = 32'h10101010;

                next_state = WRITE_X2;

            end


            WRITE_X2: begin

                WriteEnable = 1;
                rd = 5'd2;

                WriteData = 32'h01010101;

                next_state = WRITE_X3;

            end


            WRITE_X3: begin

                WriteEnable = 1;
                rd = 5'd3;

                WriteData = 32'h00000005;

                next_state = DO_ADD;

            end


            DO_ADD: begin

                rs1 = 5'd1;
                rs2 = 5'd2;

                ALUControl = 3'b000;

                WriteEnable = 1;
                rd = 5'd4;

                WriteData = ALUResult;

                next_state = DO_SUB;

            end


            DO_SUB: begin

                rs1 = 5'd1;
                rs2 = 5'd2;

                ALUControl = 3'b001;

                WriteEnable = 1;
                rd = 5'd5;

                WriteData = ALUResult;

                next_state = DO_AND;

            end


            DO_AND: begin

                rs1 = 5'd1;
                rs2 = 5'd2;

                ALUControl = 3'b010;

                WriteEnable = 1;
                rd = 5'd6;

                WriteData = ALUResult;

                next_state = DO_OR;

            end


            DO_OR: begin

                rs1 = 5'd1;
                rs2 = 5'd2;

                ALUControl = 3'b011;

                WriteEnable = 1;
                rd = 5'd7;

                WriteData = ALUResult;

                next_state = DO_XOR;

            end


            DO_XOR: begin

                rs1 = 5'd1;
                rs2 = 5'd2;

                ALUControl = 3'b100;

                WriteEnable = 1;
                rd = 5'd8;

                WriteData = ALUResult;

                next_state = DO_SLL;

            end


            DO_SLL: begin

                rs1 = 5'd1;
                rs2 = 5'd2;

                ALUControl = 3'b101;

                WriteEnable = 1;
                rd = 5'd9;

                WriteData = ALUResult;

                next_state = DO_SRL;

            end


            DO_SRL: begin

                rs1 = 5'd1;
                rs2 = 5'd2;

                ALUControl = 3'b110;

                WriteEnable = 1;
                rd = 5'd10;

                WriteData = ALUResult;

                next_state = DO_BEQ;

            end


            DO_BEQ: begin

                // Compare x1 with x1
                // Therefore Zero should become 1

                rs1 = 5'd1;
                rs2 = 5'd1;

                ALUControl = 3'b111;

                if (Zero) begin

                    WriteEnable = 1;
                    rd = 5'd11;

                    WriteData = 32'h00000001;

                end

                next_state = DONE;

            end


            DONE: begin

                WriteEnable = 0;

                next_state = DONE;

            end


            default: begin

                next_state = IDLE;

            end

        endcase

    end


    initial begin

        clk = 0;
        rst = 0;

        #2;

        rst = 1;

        #10;

        rst = 0;


        wait(state == DONE);

        #2;


        if (rf.regs[1] == 32'h10101010)
            $display("PASS x1");

        if (rf.regs[2] == 32'h01010101)
            $display("PASS x2");

        if (rf.regs[3] == 32'h00000005)
            $display("PASS x3");

        if (rf.regs[4] == 32'h11111111)
            $display("PASS ADD");

        if (rf.regs[5] == 32'h0F0F0F0F)
            $display("PASS SUB");

        if (rf.regs[6] == 32'h00000000)
            $display("PASS AND");

        if (rf.regs[7] == 32'h11111111)
            $display("PASS OR");

        if (rf.regs[8] == 32'h11111111)
            $display("PASS XOR");

        if (rf.regs[9] == 32'h20202020)
            $display("PASS SLL");

        if (rf.regs[10] == 32'h08080808)
            $display("PASS SRL");

        if (rf.regs[11] == 32'h00000001)
            $display("PASS BEQ");


        $display("--------------------------");
        $display("FSM + RF + ALU COMPLETE");
        $display("--------------------------");


        #20;

        $finish;

    end

endmodule