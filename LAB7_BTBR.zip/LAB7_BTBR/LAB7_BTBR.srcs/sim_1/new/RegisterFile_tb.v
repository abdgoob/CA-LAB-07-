`timescale 1ns / 1ps

module RegisterFile_tb;

    reg clk;
    reg rst;
    reg WriteEnable;

    reg [4:0] rs1;
    reg [4:0] rs2;
    reg [4:0] rd;

    reg [31:0] WriteData;

    wire [31:0] ReadData1;
    wire [31:0] ReadData2;


    RegisterFile uut (
        .clk(clk),
        .rst(rst),
        .WriteEnable(WriteEnable),
        .rs1(rs1),
        .rs2(rs2),
        .rd(rd),
        .WriteData(WriteData),
        .ReadData1(ReadData1),
        .ReadData2(ReadData2)
    );


    // 100 MHz equivalent simulation clock
    always #5 clk = ~clk;


    task write_register;

        input [4:0] address;
        input [31:0] data;

        begin

            @(negedge clk);

            rd = address;
            WriteData = data;
            WriteEnable = 1'b1;

            @(posedge clk);
            #1;

            WriteEnable = 1'b0;

        end

    endtask


    initial begin

        clk = 0;
        rst = 0;

        WriteEnable = 0;

        rs1 = 0;
        rs2 = 0;
        rd = 0;

        WriteData = 0;


        // ------------------------
        // RESET
        // ------------------------

        #2;
        rst = 1;

        #10;
        rst = 0;


        // ------------------------
        // TEST 1
        // Write x5 = DEADBEEF
        // ------------------------

        write_register(5'd5, 32'hDEADBEEF);

        rs1 = 5'd5;

        #2;

        if (ReadData1 == 32'hDEADBEEF)
            $display("PASS: x5 written correctly");
        else
            $display("FAIL: x5 incorrect");


        // ------------------------
        // TEST 2
        // Try writing x0
        // ------------------------

        write_register(5'd0, 32'hFFFFFFFF);

        rs1 = 5'd0;

        #2;

        if (ReadData1 == 32'h00000000)
            $display("PASS: x0 remained zero");
        else
            $display("FAIL: x0 changed");


        // TEST 3
        // Two simultaneous reads

        write_register(5'd6, 32'h12345678);
        write_register(5'd7, 32'hCAFEBABE);

        rs1 = 5'd6;
        rs2 = 5'd7;

        #2;

        if ((ReadData1 == 32'h12345678) &&
            (ReadData2 == 32'hCAFEBABE))

            $display("PASS: simultaneous reads correct");

        else
            $display("FAIL: simultaneous reads incorrect");

        // TEST 4
        // Overwrite x5

        write_register(5'd5, 32'hAAAAAAAA);

        rs1 = 5'd5;

        #2;

        if (ReadData1 == 32'hAAAAAAAA)
            $display("PASS: overwrite successful");
        else
            $display("FAIL: overwrite unsuccessful");

        // TEST 5
        // Reset
   

        rst = 1;

        #2;

        rst = 0;

        rs1 = 5'd5;
        rs2 = 5'd6;

        #2;

        if ((ReadData1 == 0) &&
            (ReadData2 == 0))

            $display("PASS: reset cleared registers");

        else
            $display("FAIL: reset unsuccessful");

        $display("REGISTER FILE TEST COMPLETE");

        #20;

        $finish;

    end

endmodule
