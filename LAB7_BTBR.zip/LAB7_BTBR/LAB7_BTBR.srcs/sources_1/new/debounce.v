module debounce_onepulse (

    input wire clk,
    input wire rst,
    input wire button,

    output wire pulse
);

    reg sync0;
    reg sync1;

    reg stable;

    reg stable_delayed;

    reg [19:0] count;


    always @(posedge clk) begin

        if (rst) begin

            sync0 <= 0;
            sync1 <= 0;

            stable <= 0;

            stable_delayed <= 0;

            count <= 0;

        end

        else begin

            sync0 <= button;
            sync1 <= sync0;


            if (sync1 == stable) begin

                count <= 0;

            end

            else begin

                if (count == 20'd999999) begin

                    stable <= sync1;

                    count <= 0;

                end

                else begin

                    count <= count + 1;

                end

            end


            stable_delayed <= stable;

        end

    end


    assign pulse = stable & ~stable_delayed;


endmodule