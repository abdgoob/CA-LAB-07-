module top_rf_alu (
input wire clk,
input wire btnC,
input wire btnU,
input wire [2:0] op_sel,
input wire write_enable_switch,
output wire [15:0] led,
output wire [6:0] seg,
output wire [3:0] an,
output wire dp
);
wire step_pulse;
reg [3:0] state;
reg [3:0] next_state;
reg [4:0] rs1;
reg [4:0] rs2;
reg [4:0] rd;
reg [31:0] WriteData;
reg [2:0] ALUControl;
reg fsm_write_enable;
wire [31:0] ReadData1;
wire [31:0] ReadData2;
wire [31:0] ALUResult;
wire Zero;
wire actual_write_enable;
reg [7:0] display_data;

// ========================================================
// STATES
// ========================================================
localparam IDLE = 4'd0;
localparam WRITE_X1 = 4'd1;
localparam WRITE_X2 = 4'd2;
localparam WRITE_X3 = 4'd3;
localparam ADD_STATE = 4'd4;
localparam SUB_STATE = 4'd5;
localparam AND_STATE = 4'd6;
localparam OR_STATE = 4'd7;
localparam XOR_STATE = 4'd8;
localparam SLL_STATE = 4'd9;
localparam SRL_STATE = 4'd10;
localparam BEQ_STATE = 4'd11;
localparam DONE = 4'd12;

// ========================================================
// BUTTON
// ========================================================
debounce_onepulse step_button (
.clk(clk),
.rst(btnC),
.button(btnU),
.pulse(step_pulse)
);

// ========================================================
// REGISTER FILE
// ========================================================
assign actual_write_enable =
fsm_write_enable
& step_pulse
& write_enable_switch;

RegisterFile rf (
.clk(clk),
.rst(btnC),
.WriteEnable(actual_write_enable),
.rs1(rs1),
.rs2(rs2),
.rd(rd),
.WriteData(WriteData),
.ReadData1(ReadData1),
.ReadData2(ReadData2)
);

// ========================================================
// ALU
// ========================================================
ALU alu (
.A(ReadData1),
.B(ReadData2),
.ALUControl(ALUControl),
.Result(ALUResult),
.Zero(Zero)
);

// STATE REGISTER
always @(posedge clk or posedge btnC) begin
if (btnC)
state <= IDLE;
else if (step_pulse)
state <= next_state;
end

// FSM
always @(*) begin
rs1 = 5'd0;
rs2 = 5'd0;
rd = 5'd0;
WriteData = 32'd0;
ALUControl = 3'b000;
fsm_write_enable = 1'b0;
next_state = state;

case (state)
// IDLE
IDLE: begin
next_state = WRITE_X1;
end

// WRITE x1
WRITE_X1: begin
rd = 5'd1;
WriteData = 32'h10101010;
fsm_write_enable = 1'b1;
next_state = WRITE_X2;
end

// WRITE x2
WRITE_X2: begin
rd = 5'd2;
WriteData = 32'h01010101;
fsm_write_enable = 1'b1;
next_state = WRITE_X3;
end

// WRITE x3
WRITE_X3: begin
rd = 5'd3;
WriteData = 32'h00000005;
fsm_write_enable = 1'b1;
next_state = ADD_STATE;
end

// ADD
// x4 = x1 + x2
ADD_STATE: begin
rs1 = 5'd1;
rs2 = 5'd2;
ALUControl = 3'b000;
rd = 5'd4;
WriteData = ALUResult;
fsm_write_enable = 1'b1;
next_state = SUB_STATE;
end

// SUB
SUB_STATE: begin
rs1 = 5'd1;
rs2 = 5'd2;
ALUControl = 3'b001;
rd = 5'd5;
WriteData = ALUResult;
fsm_write_enable = 1'b1;
next_state = AND_STATE;
end

// AND
AND_STATE: begin
rs1 = 5'd1;
rs2 = 5'd2;
ALUControl = 3'b010;
rd = 5'd6;
WriteData = ALUResult;
fsm_write_enable = 1'b1;
next_state = OR_STATE;
end

// OR
OR_STATE: begin
rs1 = 5'd1;
rs2 = 5'd2;
ALUControl = 3'b011;
rd = 5'd7;
WriteData = ALUResult;
fsm_write_enable = 1'b1;
next_state = XOR_STATE;
end

// XOR
XOR_STATE: begin
rs1 = 5'd1;
rs2 = 5'd2;
ALUControl = 3'b100;
rd = 5'd8;
WriteData = ALUResult;
fsm_write_enable = 1'b1;
next_state = SLL_STATE;
end

// SLL
SLL_STATE: begin
rs1 = 5'd1;
rs2 = 5'd2;
ALUControl = 3'b101;
rd = 5'd9;
WriteData = ALUResult;
fsm_write_enable = 1'b1;
next_state = SRL_STATE;
end

// SRL
SRL_STATE: begin
rs1 = 5'd1;
rs2 = 5'd2;
ALUControl = 3'b110;
rd = 5'd10;
WriteData = ALUResult;
fsm_write_enable = 1'b1;
next_state = BEQ_STATE;
end
// BEQ
// x11 = 1 when x1 == x1
BEQ_STATE: begin
rs1 = 5'd1;
rs2 = 5'd1;
ALUControl = 3'b111;
rd = 5'd11;
if (Zero)
WriteData = 32'h00000001;
else
WriteData = 32'h00000000;
fsm_write_enable = 1'b1;
next_state = DONE;
end
// SW2:0 selects stored result.
// Press BTNU again -> loop to IDLE.
DONE: begin
case (op_sel)
3'b000: rs1 = 5'd4;
3'b001: rs1 = 5'd5;
3'b010: rs1 = 5'd6;
3'b011: rs1 = 5'd7;
3'b100: rs1 = 5'd8;
3'b101: rs1 = 5'd9;
3'b110: rs1 = 5'd10;
3'b111: rs1 = 5'd11;
endcase
// LOOP BACK
next_state = IDLE;
end

default: begin
next_state = IDLE;
end
endcase
end

// LED DISPLAY DURING FSM
always @(*) begin
case (state)
ADD_STATE:
display_data = ALUResult[7:0];
SUB_STATE:
display_data = ALUResult[7:0];
AND_STATE:
display_data = ALUResult[7:0];
OR_STATE:
display_data = ALUResult[7:0];
XOR_STATE:
display_data = ALUResult[7:0];
SLL_STATE:
display_data = ALUResult[7:0];
SRL_STATE:
display_data = ALUResult[7:0];
BEQ_STATE:
display_data = Zero ? 8'h01 : 8'h00;
DONE:
display_data = ReadData1[7:0];
default:
display_data = ReadData1[7:0];
endcase
end

// LED OUTPUTS
assign led[7:0] = display_data;
assign led[11:8] = state;
assign led[12] = (state == DONE);
assign led[13] = Zero;
assign led[14] = actual_write_enable;
assign led[15] = write_enable_switch;


// 7 SEGMENT DISPLAY
SevenSegmentDisplay seven_seg (
.clk(clk),
.value(ReadData1[15:0]),
.seg(seg),
.an(an),
.dp(dp)
);
endmodule