module ALU (
    input wire [31:0] A,
    input wire [31:0] B,
    input wire [2:0] ALUControl,

    output reg [31:0] Result,
    output wire Zero
);

    always @(*) begin
        case (ALUControl)

            3'b000:
                Result = A + B;          // ADD

            3'b001:
                Result = A - B;          // SUB

            3'b010:
                Result = A & B;          // AND

            3'b011:
                Result = A | B;          // OR

            3'b100:
                Result = A ^ B;          // XOR

            3'b101:
                Result = A << B[4:0];    // SLL

            3'b110:
                Result = A >> B[4:0];    // SRL

            3'b111:
                Result = A - B;          // BEQ comparison

            default:
                Result = 32'b0;

        endcase
    end

    assign Zero = (Result == 32'b0);

endmodule

