
module RegisterFile (
    input wire clk,
    input wire rst,
    input wire WriteEnable,

    input wire [4:0] rs1,
    input wire [4:0] rs2,
    input wire [4:0] rd,

    input wire [31:0] WriteData,

    output wire [31:0] ReadData1,
    output wire [31:0] ReadData2
);

    reg [31:0] regs [0:31];

    integer i;

    // Synchronous write, asynchronous reset
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            for (i = 0; i < 32; i = i + 1)
                regs[i] <= 32'b0;
        end
        else begin
            // x0 cannot be written
            if (WriteEnable && (rd != 5'd0))
                regs[rd] <= WriteData;
        end
    end

    // Asynchronous reads
    // x0 always returns zero
    assign ReadData1 = (rs1 == 5'd0) ? 32'b0 : regs[rs1];
    assign ReadData2 = (rs2 == 5'd0) ? 32'b0 : regs[rs2];

endmodule
